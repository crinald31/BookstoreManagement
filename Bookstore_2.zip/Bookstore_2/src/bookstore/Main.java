/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bookstore;

/**
 *
 * @author chris
 */
import java.util.*;

public class Main {
    private static boolean test = false;
    static Bookstore store = new Bookstore();
    static Scanner scan = new Scanner(System.in);
    static ArrayList<Product> cart = new ArrayList<>();
    
        
    public static void main(String[] args) {
        int input;
        
        //a do while loop to make sure the code runs at least once and keeps running until test has been set to true
        do
        {
            System.out.println("Which of the following would you like to do?:");
            System.out.println("1. Purchase an item");
            System.out.println("2. Check membership");
            System.out.println("3. New membership registration");
            System.out.println("4. Restock Product");
            System.out.println("5. Get inventory total value");
            System.out.println("6. Exit");
            
            input = scan.nextInt();
            
            switch(input)
            {
                case 1: //tests the first option
                    System.out.println("");
                    makePurchase(store, scan, new ArrayList()); //calls the makePurchase method to make the code neater
                    break;
                case 2:
                    System.out.println("");
                    checkMembership(store, scan); //calls the checkMembership method to make the code neater
                    break;
                case 3:
                    System.out.println("");
                    registerMember(store, scan, 0); //calls the regtisterMember method to make the code neater
                    break;
                case 4:
                    System.out.println("");
                    Scanner scan = new Scanner(System.in);
                    System.out.println("What product ID do you want to restock?: ");
                    int i = scan.nextInt();
                    scan.nextLine();
                    System.out.println("How much is being restocked?: ");
                    int j = scan.nextInt();
                    store.restockProduct(i, j);
                    break;
                case 5:
                    System.out.println("");
                    System.out.println("Total value is: $" + (store.inventoryValue() - .0000000000001));
                    break;
                case 6:
                    System.out.println("Thank you for shopping."); //prompt if they wish to exit
                    test = true;
                    break;
                default:
                    System.out.println("Invalid option. Please choose 1-6"); //if options 1-4 weren't selected
            }
        } while(!test);
    }

    private static void makePurchase(Bookstore store, Scanner scan, ArrayList<Integer> purchasedIDs)
    {
        System.out.println("What would you like to buy?:");
        //ArrayList<Book> bookInv = store.getBookInv();
        //ArrayList<CD> cdInv = store.getCDInv();
        //ArrayList<DVD> dvdInv = store.getDVDInv();

        int num = 1;
        
        for(Product purchase: store.getInventory()) //searches through the entire bookInv ArrayList and prints out the details of each item
        {
            System.out.println(purchase.getID() + " " + purchase.getName());
            if(purchase instanceof Book)
            {
                System.out.print(" by " + ((Book) purchase).getAuthor() + " , $" + purchase.getPrice() + " , " + purchase.getStock() + " (Book)");
                num++;
            }
            else if(purchase instanceof CD)
            {
                System.out.print(" by " + ((CD) purchase).getArtist() + " , $" + purchase.getPrice() + " , " + purchase.getStock() + " (CD)");
            }
            else
            {
                System.out.print(" , $" + purchase.getPrice() + " , " + purchase.getStock() + " (DVD)");
            }
            System.out.println("");
        }
        
        Scanner scrn = new Scanner(System.in);
        int inp = scrn.nextInt();
        ArrayList<Product> z = store.getInventory();
        
        cart.add(z.get(inp - 1));
        
        if(z.get(inp - 1).getStock() == 1)
        {
            z.remove(inp - 1);
        }
        else
        {
            z.get(inp - 1).decrementStock();
        }
        store.setInventory(z);
        /*
        if(inp <= num)
        {
            if (inp <= bookInv.size())
            {
                cart.add(bookInv.get(inp - 1)); //adds the book item bought into the cart ArrayList
                bookInv.get(inp - 1).decrementStock(); //decrements the stock of the certain item bought for books
                System.out.println("Item added to cart");
            }
            else if (inp - bookInv.size() <= cdInv.size())
            {
                cart.add(cdInv.get(inp - 1)); //adds the cd item bought into the cart ArrayList
                cdInv.get(inp - bookInv.size() - 1).decrementStock(); //decrements the stock of the certain item bought for cds
                System.out.println("Item added to cart");
            }
            else
            {
                cart.add(dvdInv.get(inp - 1)); //adds the dvd item bought into the cart ArrayList
                dvdInv.get(inp - bookInv.size() - cdInv.size() - 1).decrementStock(); //decrements the stock of the certain item bought for dvds
                System.out.println("Item added to cart");
            }
        }
        */
        if(inp < num)
        {
            System.out.println("You have " + cart.size() + " items in your cart. Are you done shopping");
            System.out.println("1. Yes");
            System.out.println("2. No");
            
            int done = scan.nextInt();
            if(inp < num) //if statement to check if the user is done
            {
                if (done != 1)
                {
                    if (done == 2)
                    {
                        makePurchase(store, scan, purchasedIDs); //will return to the beginning of the purchase method
                    }
                    else //invalid option
                    {
                        System.out.println("Invalid. Please choose either 1 or 2");
                    }
                }
                else
                {
                    checkout(cart);
                }
            }
        }
    }
    
    private static boolean registerMember(Bookstore store, Scanner scan, int num)
    {
        System.out.println("Which membership tier would you like to register as?:");
        System.out.println("1. Free");
        System.out.println("2. Premium"); 
        
        int inp = scan.nextInt();
        if(inp < 1 || inp > 2) //makes sure the code won't run unless the user inputs the provided options
        {
            System.out.println("Invalid");
            return registerMember(store, scan, num); //returns to the start to fix the users error
        }
        else
        {
            System.out.println("Name:");
            scan.nextLine();
            String name = scan.nextLine();
            if(inp == 1) //registers the user as a member
            {
                store.addNewMember(name, false, num);
                return false;
            }
            else //registers the user as a premium member
            {
                store.addNewMember(name, true, num);
                return true;
            }
        }
    }
    
    private static void checkMembership(Bookstore store, Scanner scan)
    {
        System.out.println("Enter member ID");
        int id = 1;
        for(Member member: store.getMembers()) //searches through the entrie members array
        {
            System.out.println(id + " " + member.getName());
            id++;
        }
        for(PremiumMember premium: store.getPremium()) //searches through the entrie premium array
        {
            System.out.println(id + " " + premium.getName());
            id++;
        }
        
        int inp = scan.nextInt();
        //checks if the choice is invalid
        if(inp < 1 || inp > store.getMembers().size() + store.getPremium().size())
        {
            System.out.println("Invalid");
            return;
        }
        //prints member details
        store.memberStatus(inp);
    }  
    
    private static double getTotalPurchase(Bookstore store, ArrayList<Integer> purchasedIDs)
    {
        double total = 0;
        for(int id: purchasedIDs)
        {
            Product product = store.getProductByID(id);
            if(product != null)
            {
                total += product.getPrice();
            }
        }
        return total;
    }
    
    private static void checkout(ArrayList<Product> cart)
    {
        double totalPurchase = 0.0;
        for (Product p: cart)
        {
            totalPurchase += p.getPrice();
        }
        System.out.println("Total cost is: $" + totalPurchase);
    }
}
