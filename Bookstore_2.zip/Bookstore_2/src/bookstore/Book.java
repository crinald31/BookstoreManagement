/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author chris
 */
public class Book extends Product {
    //initializes the variables needed for the class
    private String author;

    public Book(String name, String author, double price, int stock) //sets the name, author, price, and stock amount to the item
    {
        super(name, price, stock);
        this.author = author;
    }

    public String getAuthor()
    {
        return author;
    }

    public void setAuthor(String author)
    {
        this.author = author;
    }
}
