/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author chris
 */
import java.util.*;

public class Bookstore implements BookStoreSpecification {
    //initializing ArrayLists for the inventory
    /*
    ArrayList<Book> bookInv = new ArrayList<>();
    ArrayList<CD> cdInv = new ArrayList<>();
    ArrayList<DVD> dvdInv = new ArrayList<>();
    */
    ArrayList<Member> members = new ArrayList<>();
    ArrayList<PremiumMember> premium = new ArrayList<>();
    double money = 0;

    ArrayList<Product> inventory = new ArrayList();
    private int quantity;
    
    public Bookstore()
    {
        Inventory();
        Member();
    }
    
    private void Inventory()
    {
        //creates three slots of inventory for books
        Book book1 = new Book("Fairy Tale", "Stephen King", 10.99, 10);
        Book book2 = new Book("Wonderer", "R.J. Palacio", 9.99, 8);
        Book book3 = new Book("Verity", "Colleen Hoover", 5.99, 20);
        inventory.add(book1);
        inventory.add(book2);
        inventory.add(book3);
        
        //creates three slots of inventory for cds
        CD cd1 = new CD("Thriller", "Michael Jackson", 8.99, 6);
        CD cd2 = new CD("Sour", "Olivia Rodrigo", 6.99, 8);
        CD cd3 = new CD("Fine Line", "Harry Styles", 7.99, 4);
        inventory.add(cd1);
        inventory.add(cd2);
        inventory.add(cd3);
        
        //creates three slots of inventory for dvds
        DVD dvd1 = new DVD("The Wizard of Oz", "Movie", 4.99, 9);
        DVD dvd2 = new DVD("Elvis", "Movie", 16.99, 14);
        DVD dvd3 = new DVD("Top Gun", "Movie", 11.99, 7);
        inventory.add(dvd1);
        inventory.add(dvd2);
        inventory.add(dvd3);
    }
    
    private void Member()
    {
        //creates two slots of pre registered members
        Member member1 = new Member("Christian", 2);
        Member member2 = new Member("John", 3);
        members.add(member1);
        members.add(member2);
        
        //creates two slots of pre registered premium members
        PremiumMember premMember1 = new PremiumMember("Matt", 6, false);
        PremiumMember premMember2 = new PremiumMember("Skylar", 10, true);
        premium.add(premMember1);
        premium.add(premMember2);
    }
    
    public void addNewMember(String name, boolean prem, int items)
    {
        //if statement to create a new premium member
        if(prem)
        {
            if(items == 0) //if no purchases are due
            {
                premium.add(new PremiumMember(name, items, false));
            }
            else //if purchases are due
            {
                premium.add(new PremiumMember(name, items, true));
            }
        }
        //else statement to create a normal member
        else
        {
            members.add(new Member(name, items));
        }
    }
    /*
    //gets the bookInv ArrayList
    public ArrayList<Book> getBookInv()
    {
        return bookInv;
    }
    //gets the cdInv ArrayList
    public ArrayList<CD> getCDInv()
    {
        return cdInv;
    }
    //gets the dvdInv ArrayList
    public ArrayList<DVD> getDVDInv()
    {
        return dvdInv;
    }
    */
    //gets the member ArrayList
    public ArrayList<Member> getMembers()
    {
        return members;
    }
    //gets the premium ArrayList
    public ArrayList<PremiumMember> getPremium()
    {
        return premium;
    }
    
    public ArrayList<Product> getInventory()
    {
        return inventory;
    }
    
    public void setInventory(ArrayList<Product> p)
    {
        inventory = p;
    }
    
    public Product getItemInv(int i)
    {
        return inventory.get(i - 1);
    }

    public void memberStatus(int id)
    {
        System.out.println("Member detatils:");
        if(id <= members.size()) //if statement to print out normal members details if the id number is less than or equal to the amount of normal members ids
        {
            Member member = members.get(id - 1);
            System.out.println("Name: " + member.getName());
            System.out.println("Items purchased: " + member.getPurchases());
            System.out.println("Membership: Free");
        }
        else //else statement to print out premium members details if the id number is higher than the amount of normal members id
        {
            PremiumMember member = premium.get(id - members.size() - 1);
            System.out.println("Name: " + member.getName());
            System.out.println("Items purchased " + member.getPurchases());
            System.out.println("Membership: Premium");
        }
    }
    
    public double getMoney()
    {
        return this.money;
    }
    
    public void setMoney(double m)
    {
        this.money += m;
    }
    
    public void decrementInventory(int ID)
    {
        for (Product p : inventory)
        {
            if (p.getStock() == ID)
            {
                p.decrementStock();
            }
        }
    }
    
    boolean isExist(int choice)
    {
        for(Product p: inventory)
        {
            if(p.getID() == choice)
            {
                return true;
            }
        }
        return false;
    }
    
    public Product getProductByID(int id)
    {
        for(Product p: inventory)
        {
            if(p.getID() == id)
            {
                return p;
            }
        }
        return null;
    }
    
    @Override
    public void restockProduct(int id, int quantity)
    {
        Product p = getProductByID(id);
        if(p == null)
        {
            System.out.println("Wrong product ID is provided");
            return;
        }
        p.setStock(p.getStock() + quantity);
    }
    
    @Override
    public double inventoryValue()
    {
        double grossValue = 0.0;
        for(Product p: inventory)
        {
            grossValue += (p.getPrice() * p.getStock());
        }
        return grossValue;
    }
}
