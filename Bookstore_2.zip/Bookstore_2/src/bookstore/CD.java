/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author chris
 */
public class CD extends Product {
    //initializes the variables needed for the class
    private String artist;

    public CD(String name, String artist, double price, int stock) //sets the name, artist, price, and stock amount to the item
    {
        super(name, price, stock);
        this.artist = artist;
    }

    public String getArtist()
    {
        return artist;
    }

    public void setArtist(String artist)
    {
        this.artist = artist;
    }
}
