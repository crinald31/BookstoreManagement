/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author chris
 */
public abstract class Product implements Comparable {
    private static int counter = 1;
    
    private int ID;
    private String name;
    private double price;
    private int stock;
    
    public Product(String name, double price, int stock)
    {
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.ID = Product.counter++;
    }
    
    public int getID()
    {
        return ID;
    }
    
    public void setID(int ID)
    {
        this.ID = ID;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public double getPrice()
    {
        return price;
    }
    
    public void setPrice(double price)
    {
        this.price = price;
    }
    
    public int getStock()
    {
        return stock;
    }
    
    public void setStock(int stock)
    {
        this.stock = stock;
    }
    
    public void decrementStock()
    {
        this.stock = stock - 1;
    }
    
    public int compareTo(Object o)
    {
        if(o.getClass().getSimpleName() == "Book" || o.getClass().getSimpleName() == "CD" || o.getClass().getSimpleName() == "DVD")
        {
            Product p = (Product) o;
            if(this.getPrice() == p.getPrice())
            {
                return 0;
            }
            else
            {
                return (int)(this.getPrice() - p.getPrice());
            }
        }
        else
        {
            return -1;
        }
    }
}
