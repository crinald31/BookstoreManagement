/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author chris
 */
public class PremiumMember extends Member {
    //initializes the variables needed for the class
    private boolean paidDues;

    public PremiumMember(String name, int purchases, boolean paidDues) //sets the name of the member, the amount of purchases they made, and if they have paid dues
    {
        super(name, purchases);
        this.paidDues = paidDues;
    }

    public boolean hasPaidDues()
    {
        return paidDues;
    }

    public void setPaidDues(boolean paidDues)
    {
        this.paidDues = paidDues;
    }
}
