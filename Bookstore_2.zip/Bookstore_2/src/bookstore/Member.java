/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookstore;

/**
 *
 * @author chris
 */
public class Member {
    //initializes the variables needed for the class
    private String name;
    private int purchases;

    public Member(String name, int purchases) //sets the name of the member and the amount of purchases they made
    {
        this.name = name;
        this.purchases = purchases;
    }

    public String getName() //getter for the name field
    {
        return name;
    }

    public void setName(String name) //setter for the name field
    {
        this.name = name;
    }

    public int getPurchases()
    {
        return purchases;
    }

    public void setPurchases(int purchases)
    {
        this.purchases = purchases;
    }
    
    public void incrementsPurchases(int purchases)
    {
        this.purchases += purchases;
    }
}

